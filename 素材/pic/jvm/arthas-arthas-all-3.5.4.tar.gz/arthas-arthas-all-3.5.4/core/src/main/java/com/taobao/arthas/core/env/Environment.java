package com.taobao.arthas.core.env;

public interface Environment extends PropertyResolver {

}
