package com.example.arthasspringbootstarterexample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArthasSpringBootStarterExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
