/*! apt.js v4.0.0 */
/* last modified on 20201203*/

"use strict";
window.addEventListener("message", function (event) {
    if (event.source != window) return;
    if(event.data.type && (event.data.type == "APIPOST:GETCHROMESTATUS")){
        event.source.postMessage({
            status:true,
            type:"STATUS"
        }, event.origin);
    }
    if (event.data.type && (event.data.type == "APIPOST:FROM_SEND_PAGE")) {
        //向拓展转发请求消息
        try{
            chrome.runtime.sendMessage(event.data, function (_data) {
                console.log(_data);
                let obj = {
                    type: "APIPOST:FROM_RESPONSE_PAGE",
                }
                obj["message"] = _data.message;
                obj["message1"] = _data.message1;
                obj = {
                    ...obj,
                    ..._data
                }
                event.source.postMessage(obj, event.origin);
            });
        } catch(err){
            console.log(err);
            event.source.postMessage({
                status:false,
                type:"STATUS"
            }, event.origin);
        }
       
    }
});
