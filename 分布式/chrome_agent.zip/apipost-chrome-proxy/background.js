/*! background.js v4.0.0 */
/* last modified on 20201203*/

"use strict";
var cancel;
let _user_headers = [];
let _all_headers = [];
let _apipost_os = false
let _request_headers = {}
window.AP = {
    IMG_EXTS: ["png", "jpg", "jpeg", "gif", "bmp", "ico"], //图片的格式
    ATTACHMENT_EXTS: ["rar", "zip", "mp3", "mp4", "wav", "xls", "xlsx", "dbf", "mht", "mhtml", "et", "dif", "wps", "wpt", "doc", "docx", "ppt", "rtf", "dot", "dotx", "docm", "dotm", "pps", "exe", "ppsx", "gz", "tar", "flv", "bin"], //无法预览的格式
}
let _forbidden_headers = ['accept-charset', 'accept-encoding', 'access-control-request-headers', 'access-control-request-method', 'connection', 'content-length', 'cookie', 'cookie2', 'date', 'dnt', 'expect', 'host', 'keep-alive', 'origin', 'referer', 'te', 'trailer', 'transfer-encoding', 'upgrade', 'user-agent', 'via'];

//日期格式化
Date.prototype.Format = function (fmt) {
    var o = {
        "M+": this.getMonth() + 1, //月份
        "d+": this.getDate(), //日
        "H+": this.getHours(), //小时
        "m+": this.getMinutes(), //分
        "s+": this.getSeconds(), //秒
        "q+": Math.floor((this.getMonth() + 3) / 3), //季度
        "S": this.getMilliseconds() //毫秒
    };
    if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1
        .length));
    for (var k in o)
        if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[
            k]) : (("00" + o[k]).substr(("" + o[k]).length)));
    return fmt;
}
// 点击官网
chrome.browserAction.onClicked.addListener(function (e) {
    window.open("https://beta.apipost.cn/?fr=chromeapp")
});
const ruleType = (data) => {
    const d = Object.prototype.toString.call(data);
    return d.substr(8, d.length - 9);
};
/**
 * 对象转成布尔值
 */
function _object2Bool(_obj) {
    if (_obj == null) {
        return false;
    }

    let _keys = Object.keys(_obj);
    return !!_keys.length;
}
const base64ToBlob = (base64Data) => {
    let arr = base64Data.split(','),
        fileType = arr[0].match(/:(.*?);/)[1],
        bstr = atob(arr[1]),
        l = bstr.length,
        u8Arr = new Uint8Array(l);

    while (l--) {
        u8Arr[l] = bstr.charCodeAt(l);
    }
    return new Blob([u8Arr], {
        type: fileType
    });
};
const ResponseCookie = (response) => {
  const responseCookies = [];
  const request = response.request;
  return new Promise((reslove, reject) => {
    try {
      response.headers && response.headers["set-cookie"].forEach(cookieStr => {
        let arr = cookieStr.split("; ")
        let newCookie = {};
        for (let index = 0; index < arr.length; index++) {
          let item = arr[index].trim();
          switch (item.toLowerCase()) {
            case "hostonly":
              newCookie["hostOnly"] = true;
              break;
            case "secure":
              newCookie["secure"] = true;
              break;
            case "httponly":
              newCookie["httpOnly"] = true;
              break;
            default:
              break;
          }
          let indexof = item.indexOf('=');

          //默认第一个为key value
          if (index == 0) {
            newCookie["key"] = indexof == -1 ? item : item.substr(0, indexof);
            newCookie["value"] = indexof == -1 ? "" : item.substr(indexof + 1, item.length - 1 - indexof);
            continue;
          }
          if (indexof != -1 && indexof < item.length - 1) {
            let proprety = item.substr(0, indexof).toLowerCase();
            let provalue = item.substr(indexof + 1, item.length - 1 - indexof);
            if (proprety == "domain") {
              provalue.substr(0, 1) == "." ? provalue = provalue.substr(1, provalue.length) : "";
            }
            newCookie[proprety] = provalue
          }
        }

        if (!newCookie.hasOwnProperty("domain")) {
          let url = request.requestUrl.split('//')[1];
          let newdomain = url.split('/')[0]
          newdomain = newdomain.split(':')[0];
          newCookie["domain"] = newdomain
        }
        if (!newCookie.hasOwnProperty("path")) {
          newCookie["path"] = "/"
        } else {
          //给用户处理不正常path
          if (newCookie["path"].indexOf("/") != 0) {
            let url = request.url.split('//')[1];
            let urlarr = url.split('/');
            if (urlarr.length > 2) {
              urlarr.shift();
              urlarr.pop();
              urlarr = urlarr.map(s => {
                return '/' + s
              })
              newCookie["path"] = urlarr.join("")
            } else {
              newCookie["path"] = "/"
            }
          }
        }
        if (newCookie.hasOwnProperty("domain") && newCookie.hasOwnProperty("key") &&
          newCookie.hasOwnProperty("value") && newCookie.hasOwnProperty("path")) {
          for (let property in newCookie) {
            if (property == "max-age") {
              let nowData = new Date().getTime();
              nowData = nowData + newCookie[property] * 1000;
              newCookie["expires"] = new Date(nowData)
            }
          }
          //过期删除
          if (newCookie["expires"] != undefined) {
            if (new Date(newCookie["expires"]) <= new Date()) { } else {
              responseCookies.push(newCookie)
            }
          } else {
            responseCookies.push(newCookie)
          }
        }
      })
    } catch (err) {
      // reject(err)
      reslove([])
    }
    reslove(responseCookies)
  })
}


// 接收消息
chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
    if (request.type == 'APIPOST:FROM_SEND_PAGE') {
        const { mode, request: message, id, sendType } = request.data;
        const { method, headers, url, responseType, timeout,body } = message;

        _apipost_os = true;
        _request_headers = headers;

        let CancelToken = axios.CancelToken;
        _user_headers = headers instanceof Array ? headers : [];
        let _start_timestamp = new Date().getTime();
        let axiosObj = {
            method,
            url,
            headers,
            timeout,
            responseType: "arraybuffer",
            cancelToken: new CancelToken(function executor(c) {
                // executor 函数接收一个 cancel 函数作为参数
                cancel = c;
            }),
           
            data:body,
            withCredentials: true, // 允许携带cookie
        };
        if (message["form"] !== undefined) {
            axiosObj.data = new URLSearchParams(message["form"])

        } else if (mode === "multipart/form-data") {
            let formData1 = new FormData();
            if (ruleType(message.body) === 'Array') {
                message.body && message.body.map(it => {
                    try {
                        formData1.append(it.key, new File([base64ToBlob(it.value)], it.name, { size: it.size, type: it.type }));
                    } catch (err) {
                        console.log(err);
                        formData1.append(it.key, it.value);
                    }
                })
            }

            // message["formData"].requestFiles && message["formData"].requestFiles.forEach(item => {
            //     item.value.forEach(item1 => {
            //         formData1.append(item.key, item1)
            //     })
            // })
            axiosObj.data = formData1
        }else {
            axiosObj.data = body;
        }
        console.log(axiosObj);
        axios(axiosObj).then(function (response) {
            chrome.cookies.getAll({
                url,
            },  async (cookies)=> {
                let newResponse = {
                    id,
                    sendType,
                    action: "end",
                    err: "",
                    request:{
                        ...response.config,
                        options:{
                            headers:response.config.headers
                        }
                    },
                    resTime: new Date().Format("HH:mm:ss"),
                    resMillisecond: Math.floor(new Date().getTime() - _start_timestamp),
                    resHeader: response.headers,
                    resBodyPath: "", // chrome don't response 
                    resBody: new TextDecoder('utf-8').decode(response.data),
                    resBodyBase: response.data,
                    resCode: {
                        code: response.status,
                        status: response.statusText
                    },
                    resBodySize: response.data.byteLength / 1024 / 1024,
                    method,
                    cookies,
                    netWork: {
                        agrent: 'chrome Proxy', // Desktop-Agent 桌面代理 ｜Cloud-Agent 远端服务器代理 已有
                        addresses: { // 请求地址信息
                            local: { // 发送地址信息 
                                address: '', // 地址 client.localAddress
                                family: '', // 网际协议版本 
                                port: '', // 端口号 client.localPort
                            },
                            remote: { // 请求远端地址信息  clinet._peername
                                address: '', // 地址
                                family: '', // 网际协议版本 client.remoteFamily
                                port: '', // 端口号
                            },
                        },
                    },
                }
                processingResponse(newResponse).then(val => {
                    sendResponse({
                        ...newResponse,
                        ...val,
                    });
                })
            });
        }).catch(err => {
            console.log(err)
            let newResponse1 = {
                id,
                sendType,
                action: "end",
                err: "",
                request:{
                    // options:{
                    //     headers:response.config.headers
                    // }
                },
                resTime: new Date().Format("HH:mm:ss"),
                resMillisecond: Math.floor(new Date().getTime() - _start_timestamp),
                resHeader: {},
                resBodyPath: "", // chrome don't response 
                resBody:"",
                resBodyBase: "",
                resCode: {
                    code: 405,
                    status: "error"
                },
                resBodySize: 0,
                method,
                cookies:[],
                code:-1,
                netWork: {
                    agrent: 'chrome Proxy', // Desktop-Agent 桌面代理 ｜Cloud-Agent 远端服务器代理 已有
                    addresses: { // 请求地址信息
                        local: { // 发送地址信息 
                            address: '', // 地址 client.localAddress
                            family: '', // 网际协议版本 
                            port: '', // 端口号 client.localPort
                        },
                        remote: { // 请求远端地址信息  clinet._peername
                            address: '', // 地址
                            family: '', // 网际协议版本 client.remoteFamily
                            port: '', // 端口号
                        },
                    },
                },
            }
            sendResponse({
                ...newResponse1,
                error: err.message
            });
        });
    } else if (request.type == 'APIPOST:FROM_SEND_CANCEL') {
        cancel();
    } else if (request.type == 'APIPOST:FROM_COOKIE_DELETE') {
        chrome.cookies.remove(request.message)
    } else if (request.type == 'APIPOST:FROM_COOKIE_ADD') {
        let cookie = request.message
        let newCookie = {
            name: cookie.key,
            value: cookie.value,
            domain: cookie.domain,
            path: cookie.path,
            expirationDate: (cookie.expires.getTime() / 1000 - new Date().getTime() / 1000)
        }
        if (cookie["httpOnly"] != undefined) {
            newCookie["httpOnly"] = cookie.httpOnly
        }
        chrome.cookies.set(newCookie)
    }
    return true;
});

// 更改header
chrome.webRequest.onBeforeSendHeaders.addListener(function (_request) {
    let _all_headers = _request.requestHeaders;
    const d = []
    if (_apipost_os == true) {
        console.log(11111, '进来了', _request_headers)
        _all_headers && _all_headers.map(it => {
            d.push(it)
        })
        for (let _h in _request_headers) {
            // if(){}
            if($.inArray(_h.toLowerCase(), _forbidden_headers) > -1){
                _all_headers.push({
                    name:_h,
                    value:_request_headers[_h],
                });
            }
        }
    }
    _apipost_os = false;

    // console.log(req);
    return {
        requestHeaders: _all_headers
    };
}, {
    urls: ["<all_urls>"],
    types: ["xmlhttprequest"]
}, ["requestHeaders", "blocking", "extraHeaders"]);


// 获取二维数组含有某键的下标
function array_index(array, column, key) {
    let _index = -1;
    array.map(function (value, index) {
        if (value[key].toString().toLowerCase() == column) {
            _index = index;
        }
    });

    return _index;
}
const buf2str = (buffer) => {

    let encodedString = String.fromCodePoint.apply(null, buffer);
    let decodedString = decodeURIComponent(escape(encodedString));//没有这一步中文会乱码
    return decodedString
}

// 获取二维数组的键值组成的新数组
function array_column(array, column) {
    return array.map(function (value) {
        return value[column].toString().toLowerCase();
    })
}
function _arrayBufferToBase64(buffer) {
    var binary = '';
    var bytes = new Uint8Array(buffer);
    var len = bytes.byteLength;
    for (var i = 0; i < len; i++) {
        binary += String.fromCharCode(bytes[i]);
    }
    return window.btoa(binary);
}


/**
 * 处理请求返回的结果
 */
function processingResponse(response, downLoad = false) {

    let result = {
        response: {},
        error: 0,
        errorStr: "success"
    }
    // let FileType = require('file-type');
    let content_type = response.resHeader["content-type"];
    console.log(response,'response')
    //文件后缀
    let ext = mime.getExtension(content_type);
    ext = ext ? ext : "txt";
    response = {
        resBodyType: ext,
        resBodySize: response.resBodySize,
        resBodyBase: response.resBodyBase
    };

    console.log(ext,'ext');
    if (AP.IMG_EXTS.includes(ext)) {
        // let blob = new Blob([response.body], {
        //   type: "image/*",
        // });
        response.resBodyType = "image";
        var base64Img = _arrayBufferToBase64(response.resBodyBase);
        response.resBodyBase64 = "data:image/png;base64," + base64Img;

        // 创建blob链接
        // let src = URL.createObjectURL(blob);
        // document.querySelector(".img111").setAttribute("src", src);
        // document.querySelector(".a111").setAttribute("href", src);
    } else if (AP.ATTACHMENT_EXTS.includes(ext)) {
        //TODO: 下载文件
        response.resBodyType = "other";
        result.response["responseBody"] = "";
    } else if (ext == 'pdf') {
        response.resBodyType = "pdf";
        var base64Img = _arrayBufferToBase64(response.resBodyBase);
        response.resBodyBase64 = `data:application/pdf;base64,${base64Img}`;
    } else {
        response.resBodyType = "text";
        // console.log(response.resBody);
        // response.resBody = buf2str(response.resBody);
        // result.response["responseBody"] = buf2str(response.resBody);
    }

    result.response["type"] = response.type;
    result.response["statusCode"] = response.statusCode;
    result.response["hourTime"] = response.resTime;
    result.response["responseTime"] = response.resMillisecond;
    result.response["responseCookies"] = response.responseCookies;
    result.response["requestHeaders"] = response.headers;
    result.response["responseHeaders"] = response.headers;
    if (downLoad) {
        result.response["localPath"] = "saveAndDownLoad";
        result.response["responseBody"] = "";
        apiFunc.download(response.body, "reponse" + "." + ext, content_type);
    } else {
        // let _cache_name = new Date().getTime() + "." + ext;
        if (response.resBodySize < 20) {
            // await apApi.writeFile(path.resolve(_cache_dir, "Temp"), _cache_name, response.body).then(val => {
            //     response.iframsSrc = val;
            // }).catch(err => {
            //     result.error = 1;
            //     result.errorStr = err;
            // })
        } else {
            result.error = 1;
            result.errorStr = "Error: 响应数据过大,无法预览";
        }
        result.response["localPath"] = response.iframsSrc;
    }
    return new Promise((resolve, reject) => {
        console.log(response);
        if (result.error === 1) {
            resolve(response);
        } else {
            resolve(response)
        }
        result = null;
        response = null;
    })
}